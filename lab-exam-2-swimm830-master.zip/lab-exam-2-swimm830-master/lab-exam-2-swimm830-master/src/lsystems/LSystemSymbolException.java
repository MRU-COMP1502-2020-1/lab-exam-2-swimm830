package lsystems;

public class LSystemSymbolException extends Exception {
	
	private char q;

	public LSystemSymbolException(char q) {
		this.q = q;
	}
	
	public char getSymbol() {
		return q;
	}

}
