package lsystems;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class LLine {

	char line[];
	Set<LRule> rules;
	List<LRule> b = new ArrayList<>();
	List<Character> charList = new ArrayList<>();
	int count = 0;

	public LLine(char[] start, Set<LRule> rules) {
		this.rules = rules;
		this.line = start;
	}

	public void process() throws LSystemSymbolException, LSystemLengthException {

		b.addAll(rules);

		for (int m = 0; m < line.length; m++) {
			for (int i = 0; i < b.size(); i++) {
				if (line[m] == b.get(i).getMatch()) {

					for (int n = 0; n < b.get(i).getBody().length; n++) {

						char[] c = b.get(i).getBody();

						if (c[n] != 'Q') {
							charList.add(c[n]);
						} else {
							throw new LSystemSymbolException(c[n]);
						}

					}
				}

			}
			if (charList.size() == 0) {
				throw new LSystemLengthException();
			}
		}

		line = listToArray(charList);
		charList.clear();
		b.clear();
		count++;
	}

	private char[] listToArray(List<Character> list) {
		char[] newChars = new char[list.size()];
		for (int i = 0; i < list.size(); i++) {
			newChars[i] = list.get(i);
		}
		return newChars;
	}

	public String toString() {

		return new String(line);
	}

}
